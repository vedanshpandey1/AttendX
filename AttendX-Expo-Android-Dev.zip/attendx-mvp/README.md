# AttendX — Expo Android development project

AttendX has been migrated from the original Vite/React web starter to a React Native + Expo application. The original web source files remain in `src/` where useful, while `App.tsx` is now the native app entry point.

## Current native MVP

- Native dashboard, timetable, attendance ledger, settings and 75% attendance calculator.
- SRHU BCA Section C, practical group C2 timetable seed.
- Local persistence with AsyncStorage.
- Excel matrix timetable import (`.xlsx` / `.xls`) with C2 practical filtering and a review-before-save step.
- Basic CSV/TXT timetable and holiday-date import.
- Android notification permission, per-class pre-reminders, post-class confirmation notifications and daily summary scheduling.
- Manual timetable entry and holiday exclusions.

## Important limitations

- The native importer currently handles Excel/CSV/TXT. PDF text extraction and photo/scanned timetable OCR have not yet been ported to the native app; unsupported formats are not silently accepted.
- Attendance is self-reported. Proxy entries are explicitly shown as proxy-reported, not institution-verified.
- Notifications require permission and Android may apply battery/background restrictions. Verify delivery on the target device.
- This is an MVP, not a production-validated release. The app has not been compiled or tested on a physical Android device in this environment.

## Package manager

The project uses **npm**. There was no lockfile in the original Vite project, so no existing package manager lockfile could be preserved.

## Local Android development build (Windows/macOS/Linux computer)

Install Node.js LTS and Android Studio, then install the Android SDK and configure `ANDROID_HOME` / `ANDROID_SDK_ROOT`. Enable USB debugging on your Android phone and connect it with a data-capable cable. Verify `adb devices` lists the phone.

From the project directory run:

```bash
npm install
npx expo install expo-dev-client
npx expo prebuild --clean
npx expo run:android --device
npx expo start
```

For later native dependency or app-config changes, run `npx expo prebuild --clean` before rebuilding, then `npx expo run:android --device`.

The `expo run:android` command requires a computer with the Android SDK; it cannot compile locally on an Android phone. If you only have your phone available, use an EAS cloud build instead of `expo run:android`.

## Web / iOS

This migration is currently focused on Android. iOS builds require macOS/Xcode for local compilation.
