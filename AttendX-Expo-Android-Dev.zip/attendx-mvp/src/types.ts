export type Status = "pending" | "attended" | "absent" | "proxy-reported";
export type ClassItem = { id:string; day:number; start:string; end:string; subject:string; room?:string; faculty?:string; code?:string; group?:"C1"|"C2"; category?:"lecture"|"practical"|"activity" };
export type Session = { id:string; date:string; start:string; end:string; subject:string; status:Status; intention?:string };
export type Settings = { preMinutes:number; postMinutes:number; morningSummary:boolean; perClass:boolean; postConfirm:boolean };