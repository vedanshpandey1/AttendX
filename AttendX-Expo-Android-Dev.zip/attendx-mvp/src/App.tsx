import React,{useEffect,useMemo,useState} from "react";
import {CalendarDays,Clock3,Upload,CheckCircle2,AlertTriangle,BookOpen,Settings as SettingsIcon,Bell,Plus,Trash2,FileText,CalendarOff,ChevronRight,UserRound,BrainCircuit} from "lucide-react";
import {ClassItem,Session,Settings} from "./types";
import c2Seed from "./srhu-bca-c2.json";
import {extractText,suggestClasses,parseHolidayDates,parseExcelMatrix} from "./parse";
import {upcoming,defaultSettings,iso,recoveryNeeded,safeAbsences} from "./engine";

const load=<T,>(k:string,f:T):T=>{try{return JSON.parse(localStorage.getItem(k)||"null")??f}catch{return f}};
const save=(k:string,v:unknown)=>localStorage.setItem(k,JSON.stringify(v));
const days=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
const today=iso(new Date());

export default function App(){
 const [classes,setClasses]=useState<ClassItem[]>(()=>load("ax-classes",c2Seed.classes as ClassItem[]));
 const [holidays,setHolidays]=useState<string[]>(()=>load("ax-holidays",[]));
 const [sessions,setSessions]=useState<Session[]>(()=>load("ax-sessions",[]));
 const [settings,setSettings]=useState<Settings>(()=>load("ax-settings",defaultSettings()));
 const [tab,setTab]=useState("home"); const [name,setName]=useState(()=>load("ax-name","Student"));
 const [notice,setNotice]=useState(""); const [busy,setBusy]=useState(false);
 const [draft,setDraft]=useState<ClassItem[]>([]); const [holidayDraft,setHolidayDraft]=useState<string[]>([]);
 const [showAdd,setShowAdd]=useState(false); const [form,setForm]=useState({day:1,start:"09:00",end:"10:00",subject:""});
 const schedule=useMemo(()=>upcoming(classes,holidays,14),[classes,holidays]);
 const allSessions=useMemo(()=>{
   const byId=new Map(sessions.map(s=>[s.id,s]));
   return schedule.map(s=>byId.get(s.id)||s);
 },[schedule,sessions]);
 const todays=allSessions.filter(s=>s.date===today);
 const completed=allSessions.filter(s=>s.status==="attended"||s.status==="absent");
 const attended=allSessions.filter(s=>s.status==="attended").length;
 const percent=completed.length?Math.round(attended/completed.length*100):0;
 useEffect(()=>{save("ax-classes",classes)},[classes]);
 useEffect(()=>{save("ax-holidays",holidays)},[holidays]);
 useEffect(()=>{save("ax-sessions",sessions)},[sessions]);
 useEffect(()=>{save("ax-settings",settings)},[settings]);
 useEffect(()=>{save("ax-name",name)},[name]);
 useEffect(()=>{
   if(!("Notification" in window))return;
   const tick=()=>{
     if(Notification.permission!=="granted")return;
     const now=new Date();
     for(const s of allSessions){
       if(s.status!=="pending"||s.date!==iso(now))continue;
       const [h,m]=s.start.split(":").map(Number); const start=new Date(now.getFullYear(),now.getMonth(),now.getDate(),h,m);
       const delta=Math.round((start.getTime()-now.getTime())/60000);
       const key=`ax-notified-${s.id}`;
       if(settings.perClass && delta===settings.preMinutes && !localStorage.getItem(key)){
         new Notification("Your next lecture is approaching",{body:`${s.subject} starts at ${s.start}. Open AttendX to review your plan.`}); localStorage.setItem(key,"1");
       }
     }
   };
   tick(); const id=window.setInterval(tick,30000); return ()=>clearInterval(id);
 },[allSessions,settings]);
 async function upload(file?:File,kind:"timetable"|"holiday"="timetable"){
   if(!file)return; setBusy(true);setNotice("");
   try{
     if(kind==="timetable" && /\.xlsx?$/i.test(file.name)){
       const items=await parseExcelMatrix(file,"C2");setDraft(items);
       setNotice(items.length?`Imported ${items.length} timetable entries for practical group C2. Review every row before saving.`:"No timetable entries detected. Check the Excel layout or add classes manually.");
     } else {
       const text=await extractText(file);
       if(kind==="timetable"){const items=suggestClasses(text);setDraft(items);if(!items.length)setNotice("We couldn't confidently identify classes. Review the file or add classes manually.");else setNotice(`Found ${items.length} possible classes. Review every row before saving.`)}
       else {const dates=parseHolidayDates(text);setHolidayDraft(dates);setNotice(dates.length?`Found ${dates.length} possible holiday dates. Review before saving.`:"No dates detected. Please check the document or add holidays manually.");}
     }
   }catch(e:any){setNotice(e.message||"Could not read this file.");}
   finally{setBusy(false);}
 }
 function updateDraft(id:string,patch:Partial<ClassItem>){setDraft(x=>x.map(c=>c.id===id?{...c,...patch}:c))}
 function record(id:string,status:Session["status"]){setSessions(old=>{const base=old.filter(x=>x.id!==id);const s=allSessions.find(x=>x.id===id);return s?[...base,{...s,status}]:old})}
 async function enableNotifications(){if(!("Notification" in window)){setNotice("This browser does not support notifications.");return;}const p=await Notification.requestPermission();setNotice(p==="granted"?"Notifications enabled while AttendX is active in this browser.":"Notification permission was not granted.");}
 const nav=[["home","Overview"],["schedule","Timetable"],["attendance","Attendance"],["settings","Settings"]];
 return <div className="shell"><aside className="sidebar"><div className="brand"><div className="brandmark">A</div><div><b>AttendX</b><small>YOUR ATTENDANCE. YOUR CONTROL.</small></div></div><nav>{nav.map(([id,label])=><button className={tab===id?"active":""} onClick={()=>setTab(id)} key={id}>{id==="home"?<CalendarDays/>:id==="schedule"?<Clock3/>:id==="attendance"?<BookOpen/>:<SettingsIcon/>}{label}</button>)}</nav><div className="sidefoot"><span className="avatar">{name.slice(0,1).toUpperCase()}</span><div><b>{name}</b><small>Personal workspace</small></div></div></aside>
 <main className="main"><header><div><span className="eyebrow">PERSONAL ACADEMIC ASSISTANT</span><h1>{tab==="home"?"Your day, under control":tab==="schedule"?"Your timetable":tab==="attendance"?"Attendance overview":"Preferences"}</h1></div><button className="iconbtn" onClick={enableNotifications} title="Enable notifications"><Bell/></button></header>
 {notice&&<div className="notice" onClick={()=>setNotice("")}>{notice}<span>×</span></div>}
 {tab==="home"&&<><section className="welcome"><div><span className="eyebrow">YOUR ACADEMIC COMMAND CENTER</span><h2>Good {new Date().getHours()<12?"morning":new Date().getHours()<17?"afternoon":"evening"}, {name}.</h2><p>Here is what your academic day looks like.</p></div><div className="welcomeicon"><BrainCircuit size={40}/></div></section>
 <section className="stats"><Stat label="Attendance so far" value={`${percent}%`} hint={`${attended} attended · ${completed.length} recorded`}/><Stat label="Today's lectures" value={String(todays.length)} hint="Based on your timetable"/><Stat label="Upcoming classes" value={String(allSessions.filter(s=>s.status==="pending").length)} hint="Next 14 days"/></section>
 <div className="grid2"><section className="panel"><div className="panelhead"><div><span className="eyebrow">TODAY</span><h3>Today's schedule</h3></div><button className="textbtn" onClick={()=>setTab("schedule")}>View timetable <ChevronRight size={15}/></button></div>
 {todays.length===0?<Empty icon={<CalendarDays/>} title="No classes scheduled today" detail="Upload your timetable or enjoy your free day."/>:todays.map(s=><SessionRow key={s.id} s={s} onStatus={record}/>)}</section>
 <section className="panel"><div className="panelhead"><div><span className="eyebrow">GET STARTED</span><h3>Set up AttendX</h3></div></div>
 <div className="setupitem"><div className="setupicon"><Upload/></div><div><b>Import timetable</b><p>PDF, Excel, CSV or text-based timetable.</p></div><label className="smallbtn">Upload<input type="file" accept=".pdf,.xlsx,.xls,.csv,.txt,image/*" onChange={e=>upload(e.target.files?.[0],"timetable")}/></label></div>
 <div className="setupitem"><div className="setupicon"><CalendarOff/></div><div><b>Import holiday calendar</b><p>Upload a holiday list to skip non-working days.</p></div><label className="smallbtn">Upload<input type="file" accept=".pdf,.xlsx,.xls,.csv,.txt,image/*" onChange={e=>upload(e.target.files?.[0],"holiday")}/></label></div>
 <div className="setupitem"><div className="setupicon"><Bell/></div><div><b>Enable reminders</b><p>Allow browser notifications on this device.</p></div><button className="smallbtn" onClick={enableNotifications}>Enable</button></div>
 {busy&&<p className="muted">Reading your document…</p>}
 </section></div>
 {draft.length>0&&<section className="panel"><div className="panelhead"><div><span className="eyebrow">REVIEW REQUIRED</span><h3>Confirm extracted timetable</h3></div><button className="smallbtn" onClick={()=>{setClasses(x=>[...x,...draft]);setDraft([]);setNotice("Timetable saved. Check the schedule for accuracy.")}}>Save timetable</button></div><p className="muted">Extraction is a suggestion, not a final schedule. Correct every row before saving.</p>{draft.map(c=><div className="editrow" key={c.id}><select value={c.day} onChange={e=>updateDraft(c.id,{day:Number(e.target.value)})}>{days.map((d,i)=><option value={i}>{d}</option>)}</select><input value={c.start} onChange={e=>updateDraft(c.id,{start:e.target.value})}/><input value={c.end} onChange={e=>updateDraft(c.id,{end:e.target.value})}/><input value={c.subject} onChange={e=>updateDraft(c.id,{subject:e.target.value})}/><button className="iconbtn danger" onClick={()=>setDraft(x=>x.filter(y=>y.id!==c.id))}><Trash2/></button></div>)}</section>}
 {holidayDraft.length>0&&<section className="panel"><div className="panelhead"><div><span className="eyebrow">REVIEW REQUIRED</span><h3>Confirm holiday dates</h3></div><button className="smallbtn" onClick={()=>{setHolidays(x=>[...new Set([...x,...holidayDraft])]);setHolidayDraft([]);setNotice("Holiday dates saved.")}}>Save holidays</button></div>{holidayDraft.map(d=><label className="holidayrow"><input type="checkbox" defaultChecked/> {d}</label>)}</section>}
 </>}
 {tab==="schedule"&&<><section className="panel"><div className="panelhead"><div><span className="eyebrow">WEEKLY SCHEDULE</span><h3>Manage your classes</h3></div><button className="smallbtn" onClick={()=>setShowAdd(!showAdd)}><Plus size={15}/> Add class</button></div>
 {showAdd&&<div className="editrow"><select value={form.day} onChange={e=>setForm({...form,day:+e.target.value})}>{days.map((d,i)=><option value={i}>{d}</option>)}</select><input type="time" value={form.start} onChange={e=>setForm({...form,start:e.target.value})}/><input type="time" value={form.end} onChange={e=>setForm({...form,end:e.target.value})}/><input placeholder="Subject name" value={form.subject} onChange={e=>setForm({...form,subject:e.target.value})}/><button className="smallbtn" onClick={()=>{if(form.subject.trim()){setClasses(x=>[...x,{...form,id:crypto.randomUUID()}]);setForm({...form,subject:""});setShowAdd(false)}}}>Save</button></div>}
 {classes.length===0?<Empty icon={<FileText/>} title="Your timetable is empty" detail="Upload a timetable from the Overview page or add classes manually."/>:days.map((d,i)=>{const list=classes.filter(c=>c.day===i).sort((a,b)=>a.start.localeCompare(b.start));return list.length?<div className="daygroup" key={d}><h4>{d}</h4>{list.map(c=><div className="classrow" key={c.id}><span className="time">{c.start} – {c.end}</span><b>{c.subject}</b><button className="iconbtn danger" onClick={()=>setClasses(x=>x.filter(v=>v.id!==c.id))}><Trash2/></button></div>)}</div>:null})}</section>
 <section className="panel"><div className="panelhead"><h3>Holiday calendar</h3><label className="smallbtn">Import holidays<input type="file" accept=".pdf,.xlsx,.xls,.csv,.txt,image/*" onChange={e=>upload(e.target.files?.[0],"holiday")}/></label></div>{holidays.length?holidays.sort().map(d=><div className="classrow"><span>{d}</span><button className="iconbtn danger" onClick={()=>setHolidays(x=>x.filter(v=>v!==d))}><Trash2/></button></div>):<p className="muted">No holidays imported yet.</p>}{holidayDraft.length>0&&<button className="smallbtn" onClick={()=>{setHolidays(x=>[...new Set([...x,...holidayDraft])]);setHolidayDraft([])}}>Save {holidayDraft.length} detected dates</button>}</section></>}
 {tab==="attendance"&&<section className="panel"><div className="panelhead"><div><span className="eyebrow">ATTENDANCE LEDGER</span><h3>Recent and upcoming classes</h3></div></div>{allSessions.map(s=><SessionRow key={s.id} s={s} onStatus={record}/>)}</section>}
 {tab==="settings"&&<section className="panel"><h3>Personal preferences</h3><label className="field">Display name<input value={name} onChange={e=>setName(e.target.value)}/></label><label className="field">Reminder before class<select value={settings.preMinutes} onChange={e=>setSettings({...settings,preMinutes:+e.target.value})}>{[0,5,10,15,20,30,45,60].map(v=><option value={v}>{v===0?"At class time":`${v} minutes before`}</option>)}</select></label><label className="field">Post-class confirmation<select value={settings.postMinutes} onChange={e=>setSettings({...settings,postMinutes:+e.target.value})}>{[0,5,10,15,20,30].map(v=><option value={v}>{v===0?"At class end":`${v} minutes after`}</option>)}</select></label><Toggle label="Morning schedule summary" value={settings.morningSummary} onChange={v=>setSettings({...settings,morningSummary:v})}/><Toggle label="Individual class reminders" value={settings.perClass} onChange={v=>setSettings({...settings,perClass:v})}/><Toggle label="Post-class confirmation prompts" value={settings.postConfirm} onChange={v=>setSettings({...settings,postConfirm:v})}/><div className="callout"><AlertTriangle/> Browser notifications in this prototype are reliable only while the app is open and the browser permits them. Native background scheduling is planned for the Android app.</div><button className="smallbtn" onClick={()=>{localStorage.clear();location.reload()}}>Reset local demo data</button></section>}
 <footer>AttendX MVP · Personal workspace · Data currently stored on this device</footer></main></div>
}
function Stat({label,value,hint}:{label:string,value:string,hint:string}){return <div className="stat"><span>{label}</span><strong>{value}</strong><small>{hint}</small></div>}
function Empty({icon,title,detail}:{icon:React.ReactNode,title:string,detail:string}){return <div className="empty"><div>{icon}</div><b>{title}</b><p>{detail}</p></div>}
function Toggle({label,value,onChange}:{label:string,value:boolean,onChange:(v:boolean)=>void}){return <label className="toggle"><span>{label}</span><input type="checkbox" checked={value} onChange={e=>onChange(e.target.checked)}/></label>}
function SessionRow({s,onStatus}:{s:Session,onStatus:(id:string,status:Session["status"])=>void}){
 const [confirm,setConfirm]=useState(false);
 return <div className="session"><div className="sessiontime"><b>{s.start}</b><small>{s.date===today?"Today":s.date}</small></div><div className="sessionbody"><b>{s.subject}</b><small>{s.start} – {s.end}</small><span className={`status ${s.status}`}>{s.status==="proxy-reported"?"Proxy reported":s.status==="pending"?"Awaiting confirmation":s.status}</span></div>{s.status==="pending"?<div className="actions"><button className="tinybtn" onClick={()=>onStatus(s.id,"attended")}>Attended</button><button className="tinybtn" onClick={()=>onStatus(s.id,"proxy-reported")}>Proxy</button><button className="tinybtn mutedbtn" onClick={()=>onStatus(s.id,"absent")}>Absent</button></div>:<button className="iconbtn" onClick={()=>onStatus(s.id,"pending")} title="Undo status"><CheckCircle2/></button>}</div>
}