import {ClassItem,Session,Settings} from "./types";
export const iso = (d:Date) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
export function upcoming(classes:ClassItem[], holidays:string[], days=14):Session[] {
  const out:Session[]=[]; const now=new Date();
  for(let offset=0;offset<days;offset++){
    const d=new Date(now.getFullYear(),now.getMonth(),now.getDate()+offset);
    const date=iso(d); if(holidays.includes(date)) continue;
    for(const c of classes.filter(x=>x.day===d.getDay())){
      out.push({id:`${date}-${c.id}`,date,start:c.start,end:c.end,subject:c.subject,status:"pending"});
    }
  }
  return out.sort((a,b)=>(a.date+a.start).localeCompare(b.date+b.start));
}
export function pct(s:Session[]){const done=s.filter(x=>x.status==="attended"||x.status==="absent"); if(!done.length)return 0; return Math.round(done.filter(x=>x.status==="attended").length/done.length*100);}
export function recoveryNeeded(present:number,total:number,target=75){if(target>=100)return present===total?0:Infinity; return Math.max(0,Math.ceil((target*total/100-present)/(1-target/100)));}
export function safeAbsences(present:number,total:number,target=75){return Math.max(0,Math.floor(present/(target/100)-total));}
export function defaultSettings():Settings{return {preMinutes:15,postMinutes:5,morningSummary:true,perClass:true,postConfirm:true};}