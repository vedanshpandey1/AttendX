import * as XLSX from "xlsx";
import { ClassItem } from "./types";

const DAYS: Record<string,number> = {sunday:0,monday:1,tuesday:2,wednesday:3,thursday:4,friday:5,saturday:6};
const timeRe = /(\d{1,2}[:.]\d{2})\s*(?:-|to|–)\s*(\d{1,2}[:.]\d{2})/i;
const normalizeTime = (s:string) => s.replace(".",":").padStart(5,"0");

async function ocr(source:File|HTMLCanvasElement):Promise<string> {
  const {createWorker} = await import("tesseract.js");
  const worker = await createWorker("eng");
  try { const result = await worker.recognize(source); return result.data.text; }
  finally { await worker.terminate(); }
}

export async function extractText(file:File):Promise<string> {
  const ext = file.name.split(".").pop()?.toLowerCase();
  if (ext === "xlsx" || ext === "xls" || ext === "csv") {
    const wb = XLSX.read(await file.arrayBuffer(), {type:"array"});
    return wb.SheetNames.map(n => XLSX.utils.sheet_to_csv(wb.Sheets[n])).join("\n");
  }
  if (ext === "txt") return await file.text();
  if (ext === "pdf") {
    const pdfjs = await import("pdfjs-dist");
    const pdfjsAny = pdfjs as any;
    pdfjsAny.GlobalWorkerOptions.workerSrc = new URL("pdfjs-dist/build/pdf.worker.min.mjs", import.meta.url).toString();
    const doc = await pdfjsAny.getDocument({data: await file.arrayBuffer()}).promise;
    let out = "";
    for (let p=1; p<=doc.numPages; p++) {
      const page = await doc.getPage(p); const content = await page.getTextContent();
      const pageText = content.items.map((x:any)=>x.str || "").join(" ");
      if (pageText.trim().length > 15) out += pageText + "\n";
      else {
        const viewport = page.getViewport({scale:1.8});
        const canvas = document.createElement("canvas");
        canvas.width = viewport.width; canvas.height = viewport.height;
        const ctx = canvas.getContext("2d");
        if (ctx) { await page.render({canvasContext:ctx,viewport}).promise; out += await ocr(canvas) + "\n"; }
      }
    }
    return out;
  }
  if (file.type.startsWith("image/")) return await ocr(file);
  throw new Error("Unsupported file. Upload PDF, image, Excel, CSV or TXT.");
}

function classFromCell(raw:string, day:number, start:string, end:string, group:"C1"|"C2"):ClassItem|null {
  const text=raw.replace(/\s+/g," ").trim();
  if(!text) return null;
  const groupMatch=text.match(/\b(C1|C2)\b/i);
  if(groupMatch && groupMatch[1].toUpperCase()!==group) return null;
  if(/\bC[12]\b/i.test(text) && !groupMatch) return null;

  const parts=text.split(":").map(x=>x.trim()).filter(Boolean);
  const first=parts[0] || text;
  const codeMatch=first.match(/^([A-Z]{2,4}\d{3})\s*/i);
  const code=codeMatch?.[1]?.toUpperCase() || "";
  let subject=first.replace(/^([A-Z]{2,4}\d{3})\s*/i,"").replace(/\((?:Thoery|Theory|Practical|Tutorial)\)/ig,"").trim();
  if(!subject) subject=first;
  subject=subject.replace(/^C[12]\s+/i,"").trim();

  const facultyAndRoom=parts[parts.length-1] || "";
  const roomMatch=facultyAndRoom.match(/\b(LT|Lab)\s*\d+\b/i);
  const room=roomMatch?.[0]?.replace(/\s+/g," ").trim();
  const facultyRaw=roomMatch ? facultyAndRoom.slice(0,roomMatch.index).trim() : "";
  const facultyNames:Record<string,string>={"GA":"Gaurav Aggarwal","VR":"Vinod Raturi","VK":"Vivek Katiyar","NC":"Nishant Chaturvedi","Ravindra S":"Ravindra Sharma","Sanjay K":"Sanjay Kumar"};
  const faculty=facultyNames[facultyRaw] || facultyRaw;
  const practical=/practical/i.test(text);
  const category:ClassItem["category"] = practical ? "practical" : (code ? "lecture" : "activity");
  return {id:crypto.randomUUID(),day,start,end,subject,code,faculty,room,group:practical?group:undefined,category};
}

/** Reads timetable-shaped Excel matrices: weekday labels down column A, periods across columns, and continuation rows for parallel practical groups. */
export async function parseExcelMatrix(file:File, group:"C1"|"C2"):Promise<ClassItem[]> {
  const wb=XLSX.read(await file.arrayBuffer(),{type:"array"});
  const ws=wb.Sheets[wb.SheetNames[0]];
  if(!ws) return [];
  const rows=XLSX.utils.sheet_to_json<any[]>(ws,{header:1,raw:false,defval:""});
  const headerIndex=rows.findIndex(r=>r.some((v:any)=>/11[:.]30\s*-\s*12[:.]20/i.test(String(v))));
  if(headerIndex<0) return suggestClasses(rows.map(r=>r.join(" ")).join("\n"));
  const header=rows[headerIndex].map((v:any)=>String(v||""));
  const slotColumns:number[]=[];
  const times:{start:string,end:string}[]=[];
  header.forEach((v:string,i:number)=>{
    const m=v.match(timeRe);
    if(m){
      slotColumns.push(i);
      const toClock=(value:string, slotIndex:number)=>{
        let normalized=normalizeTime(value);
        let [hh,mm]=normalized.split(":").map(Number);
        // The supplied SRHU grid writes afternoon hours as 01.xx–04.xx.
        // Once the 11:30 and 12:20 periods have passed, interpret 01–04 as 13–16.
        if(slotIndex>=2 && hh>=1 && hh<=5) hh+=12;
        return `${String(hh).padStart(2,"0")}:${String(mm).padStart(2,"0")}`;
      };
      times.push({start:toClock(m[1],times.length),end:toClock(m[2],times.length)});
    }
  });
  let currentDay:number|null=null;
  const out:ClassItem[]=[];
  for(let r=headerIndex+1;r<rows.length;r++){
    const row=rows[r];
    const dayText=String(row[0]||"").trim().toLowerCase();
    if(DAYS[dayText]!==undefined) currentDay=DAYS[dayText];
    if(currentDay===null) continue;
    for(let i=0;i<slotColumns.length;i++){
      const value=String(row[slotColumns[i]]||"").trim();
      if(!value) continue;
      const item=classFromCell(value,currentDay,times[i].start,times[i].end,group);
      if(item) out.push(item);
    }
  }
  // Remove accidental duplicates from repeated/merged worksheet cells.
  const seen=new Set<string>();
  return out.filter(x=>{const k=[x.day,x.start,x.end,x.subject,x.code||"",x.group||""].join("|");if(seen.has(k))return false;seen.add(k);return true;});
}

export function suggestClasses(text:string):ClassItem[] {
  const lines = text.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
  const found:ClassItem[] = [];
  for (const line of lines) {
    const lower = line.toLowerCase();
    const dayName = Object.keys(DAYS).find(d=>new RegExp(`\\b${d}\\b`,"i").test(lower));
    const tm = line.match(timeRe);
    if (!dayName || !tm) continue;
    const subject = line.replace(new RegExp(dayName,"i"),"").replace(tm[0],"").replace(/[|,;\t]+/g," ").trim();
    if (!subject) continue;
    found.push({id:crypto.randomUUID(),day:DAYS[dayName],start:normalizeTime(tm[1]),end:normalizeTime(tm[2]),subject,category:"lecture"});
  }
  return found;
}

export function parseHolidayDates(text:string):string[] {
  const matches = text.match(/\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b/g) || [];
  return [...new Set(matches.map(v=>{
    const [a,b,c]=v.split(/[/-]/).map(Number);
    const year = c < 100 ? 2000+c : c;
    return `${year}-${String(b).padStart(2,"0")}-${String(a).padStart(2,"0")}`;
  }).filter(v=>!v.includes("NaN")))];
}